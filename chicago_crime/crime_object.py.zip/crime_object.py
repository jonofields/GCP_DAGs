import datetime
from google.cloud import storage

def upload_blob():
        
    storage_client = storage.Client()

    date_td = datetime.today()
    
    bucket = storage_client.get_bucket('data_for_hobby_pipelines')
    blob = bucket.blob(f'{date_td}.csv')
    blob.upload_from_filename(f'crime_data/{date_td}.csv')   

    print('Data has been sent as {} to {}'.format(f'crime_data/{date_td}.csv','data_for_hobby_pipelines'))